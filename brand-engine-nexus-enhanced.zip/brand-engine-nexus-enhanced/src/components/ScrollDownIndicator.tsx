
import React from 'react';
import ScrollDownIndicator from './navbar/ScrollDownIndicator';

// Re-export the ScrollDownIndicator component from the navbar folder
export default ScrollDownIndicator;


import Industries from './industries';
export default Industries;

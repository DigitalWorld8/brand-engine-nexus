
export { default } from './Industries';

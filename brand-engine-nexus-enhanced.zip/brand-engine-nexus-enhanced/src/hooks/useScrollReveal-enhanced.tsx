/* Enhanced scroll reveal hook with smoother animations and better performance */

import { useEffect, useRef, useState, useCallback } from "react";
import { useScroll } from "./useScroll";
import { debounce } from "@/lib/utils";

interface ScrollRevealOptions {
  threshold?: number;
  rootMargin?: string;
  delay?: number;
  duration?: number;
  easing?: string;
  staggerChildren?: boolean;
  staggerDelay?: number;
}

export function useScrollReveal({ 
  threshold = 0.1, 
  rootMargin = "0px",
  delay = 0,
  duration = 300,
  easing = "cubic-bezier(0.22, 1, 0.36, 1)",
  staggerChildren = false,
  staggerDelay = 50
}: ScrollRevealOptions = {}) {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const { direction, initialScrollOccurred } = useScroll();
  const [childrenCount, setChildrenCount] = useState(0);
  
  // Check if scrolling up after initial scroll down
  const isScrollingUp = direction === 'up' && initialScrollOccurred;

  // Apply CSS variables for animation control
  useEffect(() => {
    if (ref.current) {
      // Apply animation properties to the container
      ref.current.style.setProperty('--reveal-duration', `${duration}ms`);
      ref.current.style.setProperty('--reveal-easing', easing);
      
      // Count direct children for staggered animations
      if (staggerChildren) {
        const children = ref.current.children;
        setChildrenCount(children.length);
        
        // Apply index to each child for staggered animations
        Array.from(children).forEach((child, index) => {
          (child as HTMLElement).style.setProperty('--child-index', index.toString());
          (child as HTMLElement).style.setProperty('--stagger-delay', `${staggerDelay}ms`);
        });
      }
    }
  }, [duration, easing, staggerChildren, staggerDelay]);

  // Optimized intersection observer with better performance
  const createObserver = useCallback(() => {
    if (!ref.current || isVisible) return null;
    
    return new IntersectionObserver((entries) => {
      const [entry] = entries;
      
      if (entry.isIntersecting) {
        // Use requestAnimationFrame for smoother animation triggering
        requestAnimationFrame(() => {
          // Apply animation classes with proper timing
          if (delay > 0) {
            setTimeout(() => {
              setIsVisible(true);
            }, delay);
          } else {
            setIsVisible(true);
          }
        });
        
        // Disconnect after visibility is set to true for performance
        if (ref.current) {
          observer.unobserve(ref.current);
        }
      }
    }, {
      threshold,
      rootMargin,
    });
  }, [threshold, rootMargin, delay, isVisible]);

  useEffect(() => {
    // If scrolling up after scrolling down, instantly show all elements
    if (isScrollingUp && !isVisible) {
      setIsVisible(true);
      return;
    }
    
    // Performance optimized - create observer once and only when needed
    let observer = createObserver();
    
    if (observer && ref.current) {
      observer.observe(ref.current);
    }
    
    return () => {
      if (observer) {
        observer.disconnect();
      }
    };
  }, [isScrollingUp, createObserver]);

  // Return enhanced animation properties
  return { 
    ref, 
    isVisible, 
    isScrollingUp,
    childrenCount,
    // Helper classes for different animation types
    revealClasses: isVisible ? 
      `revealed ${staggerChildren ? 'stagger-children' : ''}` : 
      'hidden',
    // Animation style properties
    animationProps: {
      duration,
      easing,
      delay
    }
  };
}

export default useScrollReveal;
